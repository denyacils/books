<?php
include ('kw.php');
$pecah=explode("\n",$kw);
foreach($pecah as $pecahan)
{
echo "<a href='".str_replace(' ','-',$pecahan).".pdf'>".$pecahan."</a><br>";
}