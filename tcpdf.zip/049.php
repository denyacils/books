<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);

$cURI = explode("/", $_SERVER["REQUEST_URI"]);
$titleku = str_replace('-',' ',$cURI[1]);
$titlebersih2 = str_replace('.pdf','',$titleku);
$titlebersih1 = str_replace('.php','',$titlebersih2);
$titlebersih = ucwords($titlebersih1);

 //kanggo replace url
$ganti=array(' ','.',':','(',')','#',' ','--',',','/',"'",';','&-xF4','&','!','@','"','&#x27;');

// Include the main TCPDF library (search for installation path).
require_once('tcpdf.php');

require_once ('kw.php');
$hasil=explode("\n",strtolower($kw));
$acak=array_rand($hasil,10);

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetTitle($titlebersih);
$pdf->SetSubject($titlebersih);
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_RIGHT);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);
// add a page
$pdf->AddPage();

$html = '<h1> '.$titlebersih.' </h1>
<span style="text-align:center"><h2>'.$titlebersih.'</h2>
<span style="text-align:center">click here to access This Book:</span></p>
<span style="text-align:center"><span style="font-size: xx-large;"><a href="http://it.denysofyan.web.id/signup.php?title='.$titlebersih.'" >Free Download</a></span></p>
<p>You can Read '.$titlebersih.' or Read Online '.$titlebersih.', Book '.$titlebersih.', And '.$titlebersih.' PDF. In electronic format take uphardly any space. If you travel a lot, you can easily download '.$titlebersih.' to read on the plane or the commuter.
<h3>Random Related '.$titlebersih.' :</h3>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[1]]).'.pdf" >'.ucwords($hasil [$acak[0]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[1]]).'.pdf">'.ucwords($hasil [$acak[1]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[2]]).'.pdf">'.ucwords($hasil [$acak[2]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[3]]).'.pdf">'.ucwords($hasil [$acak[3]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[4]]).'.pdf">'.ucwords($hasil [$acak[4]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[5]]).'.pdf">'.ucwords($hasil [$acak[5]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[6]]).'.pdf">'.ucwords($hasil [$acak[6]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[7]]).'.pdf">'.ucwords($hasil [$acak[7]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[8]]).'.pdf">'.ucwords($hasil [$acak[8]]).'</a></p>
<a href="http://'.$_SERVER['HTTP_HOST'].'/'.str_replace($ganti,'-',$hasil [$acak[9]]).'.pdf">'.ucwords($hasil [$acak[9]]).'</a></p>';



// output the HTML content
$pdf->writeHTML($html);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output($titleku.'.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
